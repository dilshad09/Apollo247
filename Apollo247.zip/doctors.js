document.getElementById("derma").addEventListener("click", function(){
    window.location.href = "dermatology.html";
})

document.getElementById("generalPhy").addEventListener("click", function(){
    window.location.href = "dermatology.html";
   

})

document.getElementById("paediatrics").addEventListener("click", function(){
    window.location.href = "dermatology.html";
})

document.getElementById("psycho").addEventListener("click", function(){
    window.location.href = "dermatology.html";
})



document.getElementById("pharmacy").addEventListener("click", function(){
    window.location.href = "pharmacy.html";
})

document.getElementById("apolloLogo").addEventListener("click", function(){
    window.location.href = "index.html";
})